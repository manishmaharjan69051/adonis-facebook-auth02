'use strict'

const Route = use('Route')
Route.on('/').render('index')





Route.group(()=>{
	
Route.get('/machinelist','MachineController.index')
Route.get('/machines','MachineController.create')
Route.post('/machines','MachineController.store')
Route.get('/machines/edit/:id','MachineController.edit')
Route.put('/machines/:id','MachineController.update')
Route.delete('/machines/:id','MachineController.destroy')

}).middleware(['auth'])



Route.group(()=>{
	Route.get('/holidaylist', 'HolidayController.index')
Route.get('/holidays','HolidayController.holidays')
Route.post('/holidays','HolidayController.store')
Route.get('/holidays/edit/:id', 'HolidayController.edit')
Route.put('/holidays/:id','HolidayController.update')
Route.delete('/holidays/:id', 'HolidayController.destroy')
}).middleware(['auth'])


Route.group(()=>{
 Route.get('/grouplist','GroupController.index')
Route.get('/groups','GroupController.create')
Route.post('/groups','GroupController.store')
Route.get('/groups/edit/:id','GroupController.edit')
Route.put('/groups/:id','GroupController.update')
Route.delete('/groups/:id','GroupController.destroy')

 }).middleware(['auth'])

Route.group(()=>{
	Route.get('/', 'LoginController.create')
  Route.post('/', 'LoginController.store')

  Route.get('register', 'RegisterController.create')
  Route.post('register', 'RegisterController.store')
})
 
 Route.group(()=>{
 	Route.get('logout', 'LoginController.delete')
 }).middleware(['auth'])


Route.get('login/facebook', 'LoginController.redirect')
Route.get('facebook/callback', 'LoginController.callback')