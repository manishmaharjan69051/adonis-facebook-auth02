'use strict'

const Schema = use('Schema')

class HolidaysSchema extends Schema {
  up () {
    this.create('holidays', (table) => {
      table.increments()
      table.date('holidayDate')
      table.string('reason')

      table.timestamps()
    })
  }

  down () {
    this.drop('holidays')
  }
}

module.exports = HolidaysSchema
