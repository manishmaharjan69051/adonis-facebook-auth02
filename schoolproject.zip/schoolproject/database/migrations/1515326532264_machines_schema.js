'use strict'

const Schema = use('Schema')

class MachinesSchema extends Schema {
  up () {
    this.create('machines', (table) => {
      table.increments()
      table.integer('serial')
      table.string('location')
      table.string('description')
      table.timestamps()
    })
  }

  down () {
    this.drop('machines')
  }
}

module.exports = MachinesSchema
