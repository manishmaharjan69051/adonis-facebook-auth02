'use strict'
const Machine = use('App/Models/Machine')
const { validate } = use('Validator')


class MachineController {
	async index({ view }){
		
		const machines = await Machine.all()
		return view.render('setting.machine.machinelist',{
			
			machines : machines.toJSON()
		})
	}

		async create({  view }){
		
		return view.render('setting.machine.machineadd')

	}

	async store({request,response,session}){
		const validation = await validate(request.all(),{
			serial: 'required|min:3|max:255',
			location: 'required|min:3|max:255',
			description: 'required|min:3|max:255'
		})
		if(validation.fails()){
			session.withErrors(validation.messages()).flashAll()
			return response.redirect('back')
		}
		
		
			const machines = new Machine()
			machines.serial = request.input('serial')
			machines.location = request.input('location')
			machines.description = request.input('description')

			await machines.save()

				session.flash({ notification : 'Post Addes'})
			return response.redirect('/machinelist')
	}

		async edit({ view, params}) {
			const machine = await Machine.find(params.id)
					
			return view.render('setting.machine.machineedit', {
				machine: machine
			})
		}

			async update({ params,request,response,session }){
			const validation = await validate(request.all(),{
				serial: 'required|min:3|max:255',
			location: 'required|min:3|max:255',
			description: 'required|min:3|max:255'
		})
		if(validation.fails()){
			session.withErrors(validation.messages()).flashAll()
			return response.redirect('back')
		}
		
		const machines = await Machine.find(params.id)
		machines.serial = request.input('serial')
		machines.location = request.input('location')
		machines.description = request.input('description')

			await machines.save()
		session.flash({ notification: 'Post Updated'})
		return response.redirect('/machinelist')
	}
			async destroy({params,response,session}){
		const machines = await Machine.find(params.id)

		await machines.delete()
		session.flash({notification:'Post deleted'})
		return response.redirect('/machinelist')

	}


	
}

module.exports = MachineController
