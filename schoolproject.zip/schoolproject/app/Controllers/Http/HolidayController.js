'use strict'

var moment = require('moment');

const Holiday = use('App/Models/Holiday')
const { validate } = use('Validator')

class HolidayController {

		async index ({view}) {
			const holidays = await Holiday.all()
			return view.render('setting.holidaylist', {
				holidays: holidays.toJSON()
			})
		}

		async holidays({view}){
			const initialHoliday = {
					holidayDate: new Date(),
					reason: ""
			};
			return view.render('setting.holidays', {
				holiday: initialHoliday
			})
		}
			async store({request,response,session}){
				const validation = await validate(request.all(),{
					
					reason:'required|min:3|max:255'
				})
				if(validation.fails()){
					session.withErrors(calidation.messages()).flashAll()
					return response.redirect('back')
				}
		
		
			const holidays = new Holiday()
			holidays.holidayDate = request.input('holidayDate')
			holidays.reason = request.input('reason')

			await holidays.save()
			session.flash({
				notification : 'Post Added'

					})
			
			return response.redirect('/holidaylist')
	}

		async edit({ view, params}) {
			const holiday = await Holiday.find(params.id)
			const holidayDate = holiday.holidayDate
			holiday.holidayDate = moment(holidayDate).format('YYYY-MM-DD')
			
			return view.render('setting.holidayedit', {
				holiday: holiday
			})
		}
	

		async update({ params,request,response,session }){
			const validation = await validate(request.all(),{
				
				reason : 'required|min:3|max:255'
			})

			if(validation.fails())
			{
				session.withErrors(validation.messages()).flashAll()
				return response.redirect('back')
			}
		
		const holidays = await Holiday.find(params.id)
		holidays.holidayDate = request.input('holidayDate')
		holidays.reason = request.input('reason')

			await holidays.save()

			session.flash({
				notification : 'Post Updated'
			})

		return response.redirect('/holidaylist')
	}


	

		async destroy({params,response,session}){
		const holidays = await Holiday.find(params.id)

		await holidays.delete()
		session.flash({
			notification : 'Deleted'
		})
		
		return response.redirect('/holidaylist')

	}
}

module.exports = HolidayController


