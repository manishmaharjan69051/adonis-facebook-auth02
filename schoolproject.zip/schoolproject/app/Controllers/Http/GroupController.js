'use strict'
const Group = use('App/Models/Group')
const { validate } = use('Validator')

class GroupController {
	async index({view}){
		const groups = await Group.all()
		return view.render('setting.group.grouplist',{
			groups : groups.toJSON()
		})
	}
	async create({ view }){
		return view.render('setting.group.groupadd')
	}

	async store({request,response,session}){
		const validation = await validate(request.all(),{
			parentId : 'required|min:1|max:255',
			groupName : 'required|min:3|max:255',
			description : 'required|min:3|max:255',
			shiftId : 'required|min:3|max:255'
		})
		if(validation.fails()){
			session.withErrors(validation.messages()).flashAll()
			return response.redirect('back')
		}
		const groups = new Group()
		groups.parentId = request.input('parentId')
		groups.groupName = request.input('groupName')
		groups.description = request.input('description')
		groups.shiftId = request.input('shiftId')
		await groups.save()
		session.flash({notification: 'Added'})
		return response.redirect('/grouplist')
	}

	async edit({view,params}){


	const groups = await Group.find(params.id)
	return view.render('setting.group.groupedit',{
		groups : groups
	})
	}

	async update({params,request,response,session}){
		const validation = await validate(request.all(),{
			parentId : 'required|min:1|max:255',
			groupName : 'required|min:3|max:255',
			description : 'required|min:3|max:255',
			shiftId : 'required|min:3|max:255'

		})
		if(validation.fails()){
			session.withErrors(validation.messages()).flashAll()
			return response.redirect('back')
		}

		const groups = await Group.find(params.id)
		groups.parentId = request.input('parentId')
		groups.groupName = request.input('groupName')
		groups.description = request.input('description')
		groups.shiftId = request.input('shiftId')

		await groups.save()
		
		session.flash({notification: 'Updated'})
		return response.redirect('/grouplist')
	}

		async destroy({params,response,session}){
		const groups = await Group.find(params.id)

		await groups.delete()
		session.flash({notification:'Deleted'})
		return response.redirect('/grouplist')

	}

}

module.exports = GroupController
