'use strict'
const User = use('App/Models/User')
const Group = use('App/Models/Group')

class LoginController {
   async create ({ view }) {
  	const groups = await Group.all()  
    return view.render('index',{
      groups : groups.toJSON()
    })
  }

  async redirect ({ ally }) {
    await ally.driver('facebook').redirect()
  }

  async callback ({ ally, auth }) {
    try {
      const fbUser = await ally.driver('facebook').getUser()

    
      const userDetails = {
        email: fbUser.getEmail(),
        token: fbUser.getAccessToken(),
        login_source: 'facebook'
      }

      // search for existing user
      const whereClause = {
        email: fbUser.getEmail()
      }

      const user = await User.findOrCreate(whereClause, userDetails)
      await auth.login(user)

      return 'Logged in'
    } catch (error) {
      return 'Unable to authenticate. Try again later'
    }
    
  }

  async store ({ auth, request, response, session }) {
   
    const { username, password } = request.all()

   
    try {
      await auth.attempt(username, password)
    } catch (e) {
    
      session.flashExcept(['password'])

      session.flash({ error: 'We cannot find any account with these credentials.' })

     
      return response.redirect('/')
    }


    return response.redirect('/')
  }

  async delete ({ auth, response }) {
   
    await auth.logout()

    return response.redirect('/')
  }
}

module.exports = LoginController
