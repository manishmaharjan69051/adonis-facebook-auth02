'use strict'

//bring in model
const Post = use('App/Models/Post')
const User = use('App/Models/User')

class PostController {
		async index({ view }){
		
		const posts = await Post.all()
		return view.render('setting.machine',{
			title : 'latest posts',
			posts : posts.toJSON()

		})

 


}

module.exports = PostController
