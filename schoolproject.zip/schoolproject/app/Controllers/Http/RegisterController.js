'use strict'

const User = use('App/Models/User')
const { validate } = use('Validator')
const Group = use('App/Models/Group')

class RegisterController {
 async  create ({ view }) {
    const groups = await Group.all()
    return view.render('authen.register',{
      groups : groups.toJSON()
    })
  }
    

  async store ({ session, request, response }) {
    
    const data = request.only(['username','name','att_id','cardNumber','groupId', 'email', 'password', 'password_confirmation'])

    const validation = await validate(data, {
      username: 'required|unique:users',
      name: 'required|unique:users',
      att_id: 'required|min:1|max:20',
      cardNumber: 'required|min:1|max:20',
      groupId: 'required|min:1|max:20',
     
      email: 'required|email|unique:users',
      password: 'required|min:3|max:20',
      password_confirmation: 'required_if:password|same:password|min:3|max:20'
    })

   
    if (validation.fails()) {
      session
        .withErrors(validation.messages())
        .flashExcept(['password'])

      return response.redirect('back')
    }

  
    delete data.password_confirmation

    
    await User.create(data)

    return response.redirect('/')
  }
}

module.exports = RegisterController
