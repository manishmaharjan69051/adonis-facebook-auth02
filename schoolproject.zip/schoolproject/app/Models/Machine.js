'use strict'

const Model = use('Model')

class Machine extends Model {
}

module.exports = Machine
