'use strict'

const Model = use('Model')

class Login extends Model {
}

module.exports = Login
