'use strict'

const Model = use('Model')

class Holiday extends Model {
}

module.exports = Holiday
