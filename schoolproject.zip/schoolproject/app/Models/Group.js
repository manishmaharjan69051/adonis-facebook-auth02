'use strict'

const Model = use('Model')

class Group extends Model {
}

module.exports = Group
