'use strict'

const Model = use('Model')

class Register extends Model {
}

module.exports = Register
