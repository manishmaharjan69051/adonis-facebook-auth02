'use strict'

const Model = use('Model')

class Post extends Model {
}

module.exports = Post
